$(function() {
  const $menu = $('.logo-menu-wrapper .main-navigation');
  const $toggleBtn = $('.logo-menu-wrapper .toggle-nav');
  
  if ($menu.length && $toggleBtn.length) {
    toggleMenu($menu, $toggleBtn, 'open')  ;
  }

  function toggleMenu($navigation, $btn, customClass) {
    $btn.on('click', function() {
      if ($btn.hasClass(customClass)) {
        $btn.removeClass(customClass);
        $navigation.css('display', 'none');
      } else {
        $btn.addClass(customClass);
        $navigation.css('display', 'block');
      }
    });
  }
});