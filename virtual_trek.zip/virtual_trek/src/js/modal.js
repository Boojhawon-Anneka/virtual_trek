$(function() {
  const $item = $('.to-bind .recent-prop-item-container');
  const $modal = $('.modal');
  const $modalClose = $modal.find('.close-modal');

  if ($item.length && $modal.length) {
    $item.on('click', function(e) {
      e.preventDefault();

      if ($(this).attr('href') != '' || undefined) {
        const link = $(this).attr('href');
        const $iframe = $modal.find('iframe');

        if ($iframe.length) {
          $iframe.attr('src', link);
          $modal.css('display', 'block');
        }
      }
    });

    if ($modalClose.length) {
      $modalClose.on('click', function() {
        $modal.css('display', 'none')
        $iframe.attr('src');
      });
    }
  }
});