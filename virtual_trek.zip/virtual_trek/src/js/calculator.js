$(function() {
  const $form = $('form.calculator-form');
  let hasRegion = false;

  let hasBed = false;
  let bedrooms = 0;
  
  let hasBedArea = false;
  let bedroomArea = 0;

  let hasBath = false;
  let bathrooms = 0;

  let hasBathArea = false;
  let bathroomArea = 0;

  let hasGarage = false;
  let garage = '';

  let hasGarageArea = false;
  let carGarageArea = 0;

  let hasPool = false;
  let pool = '';

  let hasPoolArea = false;
  let poolArea = 0;

  let floors = 0;
  let price = 0;
  let total = 0;

  if ($form.length) {
    $form.submit( function(e) {
      e.preventDefault();
      
      if ($('[name=\'region\']').val() != (null || undefined || '')) {
        hasRegion = true;
        const region = $('[name=\'region\']').val();
        
        switch (region) {
          case 'north':
            price = 4701;
            break;
          
          case 'south':
            price = 5851;
            break;
  
          case 'east':
            price = 3940;
            break;
  
          case 'west':
            price = 6179;
            break;
  
          case 'center':
            price = 7548;
            break;
  
          default:
            break;
        }
      }
  
      if ( $('[name=\'bedroom\']').val() != (null || undefined || '') ) {
        hasBed = true;
        bedrooms = $('[name=\'bedroom\']').val();
        $('[name=\'bedroom\']').next('.errMsg').addClass('hidden');
      } else {
        $('[name=\'bedroom\']').next('.errMsg').removeClass('hidden');
      }
  
      if ($('[name=\'bedroom-area\']').val() != (null || undefined || '')) {
        hasBedArea = true;
        bedroomArea = $('[name=\'bedroom-area\']').val();
        $('[name=\'bedroom-area\']').next('.errMsg').addClass('hidden');
      } else {
        $('[name=\'bedroom-area\']').next('.errMsg').removeClass('hidden');
      }

      if ($('[name=\'bath\']').val() != (null || undefined || '')) {
        hasBath = true;
        bathrooms = $('[name=\'bath\']').val();
        $('[name=\'bath\']').next('.errMsg').addClass('hidden');
      } else {
        $('[name=\'bath\']').next('.errMsg').removeClass('hidden');
      }

      if ($('[name=\'bath-area\']').val() != (null || undefined || '')) {
        hasBathArea = true;
        bathroomArea = $('[name=\'bath-area\']').val();
        $('[name=\'bath-area\']').next('.errMsg').addClass('hidden');
      } else {
        $('[name=\'bath-area\']').next('.errMsg').removeClass('hidden');
      }
      
      if ($('[name=\'garage\']:checked').val() !== undefined) {
        hasGarage = true;
        garage = $('[name=\'garage\']:checked').val();
        
        $('[name=\'garage\']').parents('.radios').find('.errMsg').addClass('hidden');

        if (garage == 'yes') {
          if ($('[name=\'garage-area\']').val() != (null || undefined || '')) {
            hasGarageArea = true;
            carGarageArea = $('[name=\'garage-area\']').val();
            $('[name=\'garage-area\']').next('.errMsg').addClass('hidden');
          } else {
            hasGarageArea = false;
            $('[name=\'garage-area\']').next('.errMsg').removeClass('hidden');
          }
        } else {
          hasGarageArea = true;
          $('[name=\'garage-area\']').next('.errMsg').addClass('hidden');
        }
      } else {
        $('[name=\'garage\']').parents('.radios').find('.errMsg').removeClass('hidden');
      }
  
      if ($('[name=\'pool\']:checked').val() != undefined) {
        hasPool = true;
        pool = $('[name=\'pool\']:checked').val();

        $('[name=\'pool\']').parents('.radios').find('.errMsg').addClass('hidden');

        if (pool == 'yes') {
          if ($('[name=\'pool-area\']').val() != (null || undefined || '')) {
            hasPoolArea = true;
            poolArea = $('[name=\'pool-area\']').val();
            $('[name=\'pool-area\']').next('.errMsg').addClass('hidden');
          } else {
            hasPoolArea = false;
            $('[name=\'pool-area\']').next('.errMsg').removeClass('hidden');
          }
        } else {
          hasPoolArea = true;
          $('[name=\'pool-area\']').next('.errMsg').addClass('hidden');
        }
      } else {
        $('[name=\'pool\']').parents('.radios').find('.errMsg').removeClass('hidden');
      }
      
      if ($('[name=\'floors\']').val() != (null || undefined || '')) {
        floors = $('[name=\'floors\']').val();
      }

      if (hasRegion && hasBed && hasBedArea && hasBath && hasBathArea && hasGarage && hasGarageArea && hasPool && hasPoolArea) {
        total += price * (bedrooms * bedroomArea);
        total += price * (bathrooms * bathroomArea);

        if (garage == 'yes') {
          total += price * carGarageArea;
        }

        if (floors > 0) {
          total += (total * 0.65);
        }

        if (pool == 'yes') {
          total += price * poolArea; 
        }
        
        alert("The esimated price is: Rs" + total)
      }
    });
  }
});