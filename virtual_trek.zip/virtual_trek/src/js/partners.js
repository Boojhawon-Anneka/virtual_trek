$(function() {
  const $slider = $('.partners-holder:not(.slick-initialized)');
  const $nextArrow = "<span class=\"slider--arrows next--arrow\"></span>";
  const $prevArrow = "<span class=\"slider--arrows prev--arrow\"></span>";

  if ($slider.length) {
    $slider.slick({
      dots: true,
      infinite: true,
      autoplay: true,
      speed: 300,
      slidesToShow: 3,
      slidesToScroll: 3,
      prevArrow: $prevArrow,
      nextArrow: $nextArrow,
      responsive: [
        {
          breakpoint: 1248,
          settings: {
            arrows: false
          }
        },
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            arrows: false
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false
          }
        }
      ]
    });
  }
});