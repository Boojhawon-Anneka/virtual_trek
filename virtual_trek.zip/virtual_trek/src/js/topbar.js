$(function() {
  const $topbar = $('.topbar');

  if ($topbar.length) {
    $(window).on('scroll', function() {
      if ($(document).scrollTop() > 50) {
        $topbar.addClass('fixed');
      } else {
        $topbar.removeClass('fixed');
      }
    })
  }
});